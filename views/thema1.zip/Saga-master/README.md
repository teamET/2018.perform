Saga [![](https://img.shields.io/github/release/Reedyn/Saga.svg?style=flat-square&label=Current%20release)](http://github.com/Reedyn/Saga/releases/latest) [![Latest downloads](https://img.shields.io/github/downloads/Reedyn/Saga/latest/total.svg?style=flat-square&label=Downloads&colorB=007ec6)](http://github.com/Reedyn/Saga/releases/latest) [![Total downloads](https://img.shields.io/github/downloads/Reedyn/Saga/total.svg?style=flat-square&label=Downloads)](http://github.com/Reedyn/Saga/releases/latest)
====

[![](http://saga.gustavlindqvist.se/content/images/2014/10/Saga-showcase.png)](http://saga.gustavlindqvist.se/2014/09/22/welcome-to-ghost/)

> **Saga** is a theme designed to look beautiful with all your media, be it a collection of images, a video you've embedded or that nice panorama you took yesterday. *To take a look at the various ways you can display your content, check out [this post](http://saga.gustavlindqvist.se/2014/09/22/welcome-to-ghost/)*.

## What is being worked on?

An [overview of issues can be seen using Zenhub](https://zenhub.io).

## Need support or just want to say something?

Hop in to [our chatroom](https://discord.gg/aY34ACs) and ask the developer directly.
